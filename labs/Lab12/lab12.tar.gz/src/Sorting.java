// Written by Kyoseung Koo

public class Sorting {
	
	/*
	 * Perform bubble sort with input argument (array).
	 * Larger (or smaller) value float to surface (like bubbles!).
	 * @param data an input array and an output sorted array.
	 */
	public static void BubbleSort(int[] data) {
		// TODO:
        //
	}
	
	/*
	 * Perform selection sort with input argument (array).
	 * Insert an element into sorted list. Similar to how we put money in our wallet!
	 * @param data an input array and an output sorted array.
	 */
	public static void SelectionSort(int[] data) {
		// TODO:
        //
	}

	/*
	 * Perform insertion sort with input argument (array).
	 * Select minimum value and swap with head.
	 * @param data an input array and an output sorted array.
	 */
	public static void InsertionSort(int[] data) {
		// TODO:
        //
	}

}
