import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

public class GraphList implements Graph {
    // TODO: variables

	GraphList(String path) {
        // TODO: constructor
	}

	@Override
	public int n() {
		// TODO:
	}

	@Override
	public void setEdge(int i, int j, int weight) {
		// TODO:
	}

	@Override
	public boolean isEdge(int v, int w) {
		// TODO:
	}

	@Override
	public void setMark(int v, int val) {
		// TODO:
	}

	@Override
	public int getMark(int v) {
		// TODO:
	}

	public static void DFS(GraphList g, int v) {
		// TODO:
	}

}
