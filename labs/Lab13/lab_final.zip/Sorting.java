import java.util.Arrays;

// Written by Kyoseung Koo

public class Sorting {
	
	/*
	 * Perform merge sort with input argument (array).
	 * Split all elements into buckets and merge two buckets incrementally.
	 * @param data is an input array.
	 * Return output sorted array.
	 */
	public static int[] MergeSort(int[] data) {
		// TODO:
	}
	
	/*
	 * Perform quick sort with input argument (array).
	 * Left side of pivot is smaller, right side of pivot is larger.
	 * @param data is an input array and an output sorted array.
	 */
	public static void QuickSort(int[] data) {
		// TODO:
	}

}
